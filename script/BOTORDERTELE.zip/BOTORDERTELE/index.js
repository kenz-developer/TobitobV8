const TelegramBot = require("node-telegram-bot-api");
require("dotenv").config();
const fs = require("fs")
const { loadCommands } = require("./on");

const bot = new TelegramBot(process.env.BOT_TOKEN, { polling: true });

console.log("🤖 Bot sedang berjalan...");

const updateExp = (userId, username) => {
  let database;
  try {
    database = JSON.parse(fs.readFileSync("./database/database.json", "utf-8"));
  } catch (err) {
    database = [];
  }

  let user = database.find(u => u.id === userId);

  if (!user) {
    user = {
      id: userId,
      username: username,
      saldo: 0,
      dana: 0,
      exp: 0,
      level: 1
    };
    database.push(user);
  }

  user.exp += 1; // EXP bertambah 1 setiap command
  if (user.exp >= 100) {
    user.level += 1;
    user.exp = 0; // Reset EXP setelah naik level
  }

  fs.writeFileSync("./database/database.json", JSON.stringify(database, null, 2));
};

// Middleware untuk menangkap semua command dan menambah EXP
bot.on("message", (msg) => {
  if (!msg.text || !msg.text.startsWith("/")) return; // Hanya command yang dihitung

  const userId = msg.from.id;
  const username = msg.from.username || "Tidak Ada";
  updateExp(userId, username);
});


loadCommands(bot);