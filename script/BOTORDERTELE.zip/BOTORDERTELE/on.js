const axios = require("axios")
const fs = require("fs")
const path = require("path")
const chalk = require("chalk").default;



module.exports.loadCommands = (bot) => {
  
    bot.onText(/\/(.+)/, (msg, match) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const userName = msg.from.first_name || "Tidak ada nama";
        const command = match[0]; // Command yang diketik user
        const timeStamp = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

console.log(chalk.bgBlue.bold(`
[ COMMAND BOT ] 
ID: ${userId}
Nama: ${userName}
Waktu: ${timeStamp}
Command: ${command}`));
    });
  

//~~~~~~~~~~~< MENU COMMMAND >~~~~~~~~~~~~~//  
const { exec } = require("child_process");

bot.onText(/\/menu$/, (msg) => {
  const chatId = msg.chat.id;

  const menuText = `
┏━━━━━━━━━━━━━━━┓
┃ 📌 MENU UTAMA ┃
┗━━━━━━━━━━━━━━━┛

🔹 /order - Beli Produk Digital
🔹 /statusdone - Konfirmasi Transaksi
🔹 /listdana - List Harga Saldo DANA
🔹 /adduserdb - Tambah User Database
🔹 /userdb - Lihat User Database
🔹 /me - Profil Pengguna
🔹 /applesearch - Cari Lagu Apple Music
🔹 /deposit - Deposit Saldo
🔹 /beliscript - Beli Script Dengan QRIS
🔹 /stokvps - Lihat Stok VPS Tersedia
🔹 /belivps - Beli VPS Otomatis
🔹 /order-kuota - Beli Kuota Internet
🔹 /addkuota - Tambah Produk Kuota
🔹 /ytmp4 - Download Video YouTube
🔹 /rekaptransaksi - Rekap Keuntungan
🔹 /tebakkata - Uji Kepintaran Anda
🔹 /shorturl - Perpendek Link
🔹 /receipt - Cetak Struktur Pembayaran
`;

  const menuButtons = {
    reply_markup: JSON.stringify({
      inline_keyboard: [
        [{ text: "👑 Website", url: "https://www.fiturbotwa.kenzcode.biz.id/" }],
        [{ text: "📜 Script", url: "https://github.com/alzzhosting" }],
        [{ text: "📌 Panduan", callback_data: "menu_panduan" }]
      ]
    })
  };

  const imagePath = "menu.jpg"; // Pastikan ada file gambar ini di direktori bot

  if (fs.existsSync(imagePath)) {
    bot.sendPhoto(chatId, imagePath, { caption: menuText, parse_mode: "Markdown", ...menuButtons });
  } else {
    bot.sendMessage(chatId, menuText, menuButtons);
  }
});

// Handle Callback Query
bot.on("callback_query", (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const data = callbackQuery.data;

  if (data === "menu_owner") {
    bot.editMessageText(
      `
┏━━━━━━━━━━━━━━━┓
┃ 👑 OWNER MENU ┃
┗━━━━━━━━━━━━━━━┛

🔹 /adduserdb - Tambah User Database
🔹 /rekaptransaksi - Rekap Keuntungan
      `, 
      { chat_id: chatId, message_id: callbackQuery.message.message_id, parse_mode: "Markdown" }
    );
  }

  if (data === "menu_script") {
    bot.editMessageText(
      `
┏━━━━━━━━━━━━━━━┓
┃ 📜 SCRIPT MENU ┃
┗━━━━━━━━━━━━━━━┛

🔹 /beliscript - Beli Script Dengan QRIS
🔹 /stokvps - Lihat Stok VPS Tersedia
🔹 /stoksc - Lihat Stok Script Tersedia
      `, 
      { chat_id: chatId, message_id: callbackQuery.message.message_id, parse_mode: "Markdown" }
    );
  }

  if (data === "menu_panduan") {
    bot.editMessageText(
      `
┏━━━━━━━━━━━━━━━┓
┃ 📌 PANDUAN MENU ┃
┗━━━━━━━━━━━━━━━┛

🔹 /order - Cara Beli Produk Digital
🔹 /deposit - Cara Deposit Saldo
      `, 
      { chat_id: chatId, message_id: callbackQuery.message.message_id, parse_mode: "Markdown" }
    );
  }
});

//~~~~~~~~~~~~~~< START COMMAND >~~~~~~~~~~~~~~//

    bot.onText(/\/start/, (msg) => {
        const chatId = msg.chat.id;
        bot.sendMessage(chatId, "🔥 Selamat datang! Gunakan perintah /menu untuk memulai.");
    });
    
    const databaseFile = "./database/database.json";
    function getUserDatabase() {
  if (!fs.existsSync(databaseFile)) return [];

  try {
    const data = JSON.parse(fs.readFileSync(databaseFile, "utf-8"));
    return Array.isArray(data) ? data : [];
  } catch (err) {
    console.error("Gagal membaca database:", err);
    return [];
  }
}

//~~~~~~~~~~~< USERDB COMMAND >~~~~~~~~~~~//

bot.onText(/\/userdb/, async (msg) => {
  const chatId = msg.chat.id;
  const users = getUserDatabase();

  if (users.length === 0) {
    return bot.sendMessage(chatId, "📂 Database kosong.");
  }

  // Urutkan berdasarkan EXP dari terbesar ke terkecil
  users.sort((a, b) => b.exp - a.exp);
  const topUsers = users.slice(0, 10);

  let text = "📊 *User Database (Top 10)*\n\n";
  topUsers.forEach((user, index) => {
    text += `${index + 1}. *${user.username || "Tanpa Nama"}*\n`;
    text += `   🆔 ID: ${user.id}\n`;
    text += `   🏆 Level: ${user.level || 1}\n`;
    text += `   🔥 EXP: ${user.exp}\n\n`;
  });

  text += `👥 *Total Users:* ${users.length}`;

  bot.sendMessage(chatId, text, { parse_mode: "Markdown" });
});

//~~~~~~~~~~< ADD USER DB >~~~~~~~~~//

const databaseFile1 = "./database/database.json";

function loadDatabase() {
  if (!fs.existsSync(databaseFile1)) return [];
  try {
    return JSON.parse(fs.readFileSync(databaseFile1, "utf-8"));
  } catch (err) {
    console.error("Gagal membaca database:", err);
    return [];
  }
}

function saveDatabase(data) {
  fs.writeFileSync(databaseFile1, JSON.stringify(data, null, 2));
}

bot.onText(/\/adduserdb (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const targetId = parseInt(match[1]);
  const userName = msg.from.username || `User_${targetId}`;

  if (isNaN(targetId)) {
    return bot.sendMessage(chatId, "⚠️ Format salah! Gunakan: `/adduserdb [id]`", { parse_mode: "Markdown" });
  }

  let users = loadDatabase();

  // Cek apakah user sudah ada di database
  if (users.some(user => user.id === targetId)) {
    return bot.sendMessage(chatId, `⚠️ User dengan ID *${targetId}* sudah ada di database!`, { parse_mode: "Markdown" });
  }

  const newUser = {
    id: targetId,
    username: userName,
    level: 1,
    exp: 0
  };

  users.push(newUser);
  saveDatabase(users);

  bot.sendMessage(chatId, `✅ User *${userName}* (ID: *${targetId}*) berhasil ditambahkan ke database!`, { parse_mode: "Markdown" });
});

//~~~~~~~~~~~< DANA COMMAND >~~~~~~~~~~~~~//
const databaseDana = "./database/listdana.json";
const itemsPerPage = 7;

function loadDatabase() {
  if (!fs.existsSync(databaseDana)) return [];
  try {
    return JSON.parse(fs.readFileSync(databaseDana, "utf-8"));
  } catch (err) {
    console.error("Gagal membaca database:", err);
    return [];
  }
}

bot.onText(/^\/listdana(?: (\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const page = parseInt(match[1]) || 1;

  let data = loadDatabase();
  if (data.length === 0) {
    return bot.sendMessage(chatId, "⚠️ Data saldo DANA tidak tersedia.");
  }

  const totalPages = Math.ceil(data.length / itemsPerPage);
  if (page > totalPages || page < 1) {
    return bot.sendMessage(chatId, `⚠️ Halaman tidak valid. Pilih halaman antara 1 - ${totalPages}.`);
  }

  const startIndex = (page - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const items = data.slice(startIndex, endIndex);

  let message = `📌 *List Harga Saldo Dana (Halaman ${page}/${totalPages}):*\n\n`;

  items.forEach(item => {
    message += `━━━━━━━━━━━━━━━━━\n`;
    message += `🔹 *Kode:* ${item.kode}\n`;
    message += `📌 *Keterangan:* ${item.keterangan}\n`;
    message += `📦 *Produk:* ${item.produk}\n`;
    message += `🗂️ *Kategori:* ${item.kategori}\n`;
    message += `💰 *Harga:* Rp${item.harga.toLocaleString("id-ID")}\n`;
    message += `📌 *Status:* ${item.status ? "✅ Tersedia" : "❌ Tidak Tersedia"}\n\n`;
  });

  message += `Gunakan *\/listdana [halaman]* untuk melihat halaman lainnya.`;

  bot.sendMessage(chatId, message, { parse_mode: "Markdown" });
});

//~~~~~~~~~~~< ORDER COMMAND >~~~~~~~~~~~//
bot.onText(/^\/order (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const username = msg.from.username || "NoUsername";
  const args = match[1].split("|");

  if (args.length !== 2) {
    return bot.sendMessage(chatId, "⚠️ Format salah! Gunakan: `/order KODE|NOMOR`", { parse_mode: "Markdown" });
  }

  const kode = args[0].trim().toUpperCase();
  const nomor = args[1].trim();

  // Baca data harga dari listdana.json
  let listDana;
  try {
    listDana = JSON.parse(fs.readFileSync("database/listdana.json", "utf-8"));
  } catch (err) {
    return bot.sendMessage(chatId, "❌ Gagal membaca daftar harga, cek kembali file database!");
  }

  // Cari kode di dalam database
  const produk = listDana.find(item => item.kode === kode);
  if (!produk) {
    return bot.sendMessage(chatId, `⚠️ Kode *${kode}* tidak ditemukan! Cek daftar harga dengan /listdana`, { parse_mode: "Markdown" });
  }

  const jamOrder = new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });
  const tanggalOrder = new Date().toLocaleDateString("id-ID");

  // ID transaksi & global (random)
  const idTransaksi = Math.floor(1000000000000 + Math.random() * 9000000000000);
  const idGlobal = Math.floor(100000000 + Math.random() * 900000000);

  const response = `🛍️ *P R O S E S*\n\n` +
    `🆔 *ID Transaksi:* ${idTransaksi}\n` +
    `🌐 *ID Global:* ${idGlobal}\n` +
    `🕘 *Jam Order:* ${jamOrder}\n\n` +
    `T#${idGlobal} R#${idTransaksi} *${produk.keterangan}* D1.${nomor} akan diproses.\n` +
    `Saldo -${produk.harga} @${jamOrder}\n\n` +
    `📌 Silakan scan QRIS di bawah untuk pembayaran.\n\n` +
    `Jika sudah bayar, kirim bukti transfer ke admin.`;

  // Simpan order ke database/orderdana.json
  const orderData = {
    idTransaksi,
    idGlobal,
    userId,
    username,
    nomor,
    kodeProduk: kode,
    harga: produk.harga,
    keterangan: produk.keterangan,
    jamOrder,
    tanggalOrder,
    status: "PENDING"
  };

  let orderDatabase = [];
  try {
    orderDatabase = JSON.parse(fs.readFileSync("./database/orderdana.json", "utf-8"));
  } catch (err) {
    fs.writeFileSync("./database/orderdana.json", JSON.stringify([], null, 2));
  }

  orderDatabase.push(orderData);
  fs.writeFileSync("./database/orderdana.json", JSON.stringify(orderDatabase, null, 2));

  // Kirim gambar QRIS dan pesan
  bot.sendPhoto(chatId, "qris.jpg", { caption: response, parse_mode: "Markdown" });
});

//~~~~~~~~~~~~< STATUS DONE COMMAND >~~~~~~~~~~~~~//
const fs = require("fs");

bot.onText(/\/statusdone (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const args = match[1].trim();

  if (!args) {
    return bot.sendMessage(chatId, "⚠️ Format salah! Gunakan: `/statusdone ID_TRANSAKSI`", { parse_mode: "Markdown" });
  }

  let orderDatabase;
  try {
    orderDatabase = JSON.parse(fs.readFileSync("./database/orderdana.json", "utf-8"));
  } catch (err) {
    return bot.sendMessage(chatId, "❌ Gagal membaca database order!");
  }

  // Cari order berdasarkan ID transaksi
  const index = orderDatabase.findIndex(order => order.idTransaksi.toString() === args);
  if (index === -1) {
    return bot.sendMessage(chatId, `⚠️ Tidak ditemukan order dengan ID: *${args}*`, { parse_mode: "Markdown" });
  }

  if (orderDatabase[index].status === "DONE") {
    return bot.sendMessage(chatId, `⚠️ Order dengan ID *${args}* sudah selesai sebelumnya!`, { parse_mode: "Markdown" });
  }

  orderDatabase[index].status = "DONE";

  // Simpan kembali ke database
  fs.writeFileSync("./database/orderdana.json", JSON.stringify(orderDatabase, null, 2));

  bot.sendMessage(chatId, `✅ Order dengan ID *${args}* berhasil diperbarui menjadi *DONE*!`, { parse_mode: "Markdown" });
});

//~~~~~~~~~~~~~~< ME COMMAND >~~~~~~~~~~~~~//

bot.onText(/^\/me$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const username = msg.from.username || "Tidak Ada";

  let database;
  try {
    database = JSON.parse(fs.readFileSync("./database/database.json", "utf-8"));
  } catch (err) {
    database = [];
  }

  let user = database.find(u => u.id === userId);

  if (!user) {
    return bot.sendMessage(chatId, "❌ Kamu belum terdaftar di database!", { parse_mode: "Markdown" });
  }

  const profileMessage = `
👤 *Profil Anda*
╔══❖
║ 🆔 ID: ${user.id}
║ 📛 Username: ${user.username}
║ 💰 Saldo: ${user.saldo}
║ 💳 Dana: ${user.dana}
║ 🎖 EXP: ${user.exp} / 100
║ 🔺 Level: ${user.level}
╚═══════════❖
  `;

  bot.sendMessage(chatId, profileMessage, { parse_mode: "Markdown" });
});

//~~~~~~~~~~~~~~< APPLE COMMAND >~~~~~~~~~~~~//
const axios = require("axios");

bot.onText(/\/applesearch (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const query = match[1];

  if (!query) {
    return bot.sendMessage(chatId, "⚠️ Masukin nama lagu yang mau dicari! Contoh: `/applesearch Stay`");
  }

  bot.sendMessage(chatId, "🔍 Sedang mencari lagu di Apple Music...");

  try {
    const { data } = await axios.get(`https://www.api.im-rerezz.xyz/api/apple-search?query=${encodeURIComponent(query)}`);

    if (!data || !data.result || data.result.length === 0) {
      return bot.sendMessage(chatId, "❌ Gak nemu lagunya, coba cek lagi namanya!");
    }

    const songs = data.result.slice(0, 5); // Ambil 5 hasil pertama
    let hasil = "🎵 *Hasil Pencarian Apple Music:*\n\n";

    songs.forEach((song) => {
      hasil += `🎶 *${song.title}* - ${song.artist}\n`;
      hasil += `📀 *Album:* ${song.album}\n`;
      hasil += `📅 *Rilis:* ${song.release_date}\n`;
      hasil += `🔗 *Link:* [Dengerin](${song.url})\n\n`;
    });

    bot.sendMessage(chatId, hasil, { parse_mode: "Markdown" });
  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mencari lagu.");
  }
});

//~~~~~~~~~~~~~~< DEPOSIT COMMAND >~~~~~~~~~~~~~~//
const ownerId = 7299507029;

bot.onText(/^\/deposit (.+)$/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const username = msg.from.username || "Tidak Ada";
  const [jumlah, nomor] = match[1].split("|");

  if (!jumlah || !nomor) return bot.sendMessage(chatId, "❌ Format salah!\nContoh: `/deposit 1000|085912345678`", { parse_mode: "Markdown" });

  let depositDB;
  try {
    depositDB = JSON.parse(fs.readFileSync("database/deposit.json", "utf-8"));
  } catch (err) {
    depositDB = [];
  }

  const depositId = depositDB.length + 1;
  const depositData = {
    id: depositId,
    userId,
    username,
    jumlah: parseInt(jumlah),
    nomor,
    status: "Pending"
  };

  depositDB.push(depositData);
  fs.writeFileSync("database/deposit.json", JSON.stringify(depositDB, null, 2));

  bot.sendMessage(chatId, `✅ Permintaan deposit Rp${jumlah.toLocaleString()} telah diterima!\n⏳ Menunggu konfirmasi admin...`);

  const keyboard = {
    reply_markup: {
      inline_keyboard: [
        [
          { text: "✅ Konfirmasi", callback_data: `confirm_${depositId}_${userId}` },
          { text: "❌ Tolak", callback_data: `reject_${depositId}_${userId}` }
        ]
      ]
    }
  };

  bot.sendMessage(ownerId, `📩 *Permintaan Deposit Baru!*\n\n👤 User: @${username}\n💰 Nominal: Rp${jumlah.toLocaleString()}\n📱 Nomor: ${nomor}\n\n🔽 Pilih tindakan:`, { 
    parse_mode: "Markdown", 
    ...keyboard 
  });
});

bot.on("callback_query", (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const data = callbackQuery.data.split("_");
  const action = data[0];
  const depositId = parseInt(data[1]);
  const userId = parseInt(data[2]);

  let depositDB;
  try {
    depositDB = JSON.parse(fs.readFileSync("database/deposit.json", "utf-8"));
  } catch (err) {
    return bot.sendMessage(chatId, "🚫 Database deposit tidak ditemukan.");
  }

  let deposit = depositDB.find(d => d.id === depositId);
  if (!deposit) return bot.sendMessage(chatId, "❌ Data deposit tidak ditemukan.");

  if (action === "confirm") {
    deposit.status = "Confirmed";
    fs.writeFileSync("database/deposit.json", JSON.stringify(depositDB, null, 2));

    bot.sendMessage(userId, `✅ *Deposit Dikonfirmasi!*\n\n💰 Nominal: Rp${deposit.jumlah.toLocaleString()}\n📱 Nomor: ${deposit.nomor}\n\n🎉 Dana telah masuk ke saldo Anda!`, { parse_mode: "Markdown" });

    bot.sendMessage(chatId, `✅ Deposit Rp${deposit.jumlah.toLocaleString()} telah dikonfirmasi.`);
  } else if (action === "reject") {
    deposit.status = "Rejected";
    fs.writeFileSync("database/deposit.json", JSON.stringify(depositDB, null, 2));

    bot.sendMessage(userId, `❌ *Deposit Ditolak!*\n\n💰 Nominal: Rp${deposit.jumlah.toLocaleString()}\n📱 Nomor: ${deposit.nomor}\n\n⚠️ Silakan hubungi admin untuk informasi lebih lanjut.`, { parse_mode: "Markdown" });

    bot.sendMessage(chatId, `❌ Deposit Rp${deposit.jumlah.toLocaleString()} telah ditolak.`);
  }
});

//~~~~~~~~~~~~< SCRIPT COMMAND >~~~~~~~~~~~~~//
bot.onText(/^\/addscript$/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  bot.sendMessage(chatId, "📝 Masukkan nama script:");
  bot.once("message", (msg1) => {
    let namaScript = msg1.text;

    bot.sendMessage(chatId, "💰 Masukkan harga script (tanpa titik/koma):");
    bot.once("message", (msg2) => {
      let hargaScript = parseInt(msg2.text);
      if (isNaN(hargaScript)) return bot.sendMessage(chatId, "❌ Harga harus berupa angka.");

      bot.sendMessage(chatId, "📖 Masukkan deskripsi script:");
      bot.once("message", (msg3) => {
        let deskripsiScript = msg3.text;

        bot.sendMessage(chatId, "📦 Masukkan stok script:");
        bot.once("message", (msg4) => {
          let stokScript = parseInt(msg4.text);
          if (isNaN(stokScript)) return bot.sendMessage(chatId, "❌ Stok harus berupa angka.");

          let scriptDB;
          try {
            scriptDB = JSON.parse(fs.readFileSync("database/scriptlist.json", "utf-8"));
          } catch (err) {
            scriptDB = [];
          }

          let scriptData = {
            id: scriptDB.length + 1,
            nama: namaScript,
            harga: hargaScript,
            deskripsi: deskripsiScript,
            stok: stokScript
          };

          scriptDB.push(scriptData);
          fs.writeFileSync("database/scriptlist.json", JSON.stringify(scriptDB, null, 2));

          bot.sendMessage(chatId, `✅ Script berhasil ditambahkan!\n\n📜 *Nama:* ${namaScript}\n💰 *Harga:* Rp${hargaScript.toLocaleString()}\n📖 *Deskripsi:* ${deskripsiScript}\n📦 *Stok:* ${stokScript}`, { parse_mode: "Markdown" });
        });
      });
    });
  });
});

//~~~~~~~~< VPSADD COMMAND >~~~~~~~~//

bot.onText(/^\/addvps$/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  bot.sendMessage(chatId, "📝 Masukkan nama VPS:");
  bot.once("message", (msg1) => {
    let namaVps = msg1.text;

    bot.sendMessage(chatId, "💰 Masukkan harga VPS (tanpa titik/koma):");
    bot.once("message", (msg2) => {
      let hargaVps = parseInt(msg2.text);
      if (isNaN(hargaVps)) return bot.sendMessage(chatId, "❌ Harga harus berupa angka.");

      bot.sendMessage(chatId, "📖 Masukkan deskripsi VPS:");
      bot.once("message", (msg3) => {
        let deskripsiVps = msg3.text;

        bot.sendMessage(chatId, "📦 Masukkan stok VPS:");
        bot.once("message", (msg4) => {
          let stokVps = parseInt(msg4.text);
          if (isNaN(stokVps)) return bot.sendMessage(chatId, "❌ Stok harus berupa angka.");

          let scriptDB;
          try {
            scriptDB = JSON.parse(fs.readFileSync("database/vpslist.json", "utf-8"));
          } catch (err) {
            scriptDB = [];
          }

          let scriptData = {
            id: scriptDB.length + 1,
            nama: namaVps,
            harga: hargaVps,
            deskripsi: deskripsiVps,
            stok: stokVps
          };

          scriptDB.push(scriptData);
          fs.writeFileSync("database/vpslist.json", JSON.stringify(scriptDB, null, 2));

          bot.sendMessage(chatId, `✅ VPS berhasil ditambahkan!\n\n📜 *Nama:* ${namaVps}\n💰 *Harga:* Rp${hargaVps.toLocaleString()}\n📖 *Deskripsi:* ${deskripsiVps}\n📦 *Stok:* ${stokVps}`, { parse_mode: "Markdown" });
        });
      });
    });
  });
});

//~~~~~~~~~~~~< BUY SCRIPT COMMAND >~~~~~~~~~~~~//
bot.onText(/^\/beliscript$/, (msg) => {
  const chatId = msg.chat.id;

  let scriptDB;
  try {
    scriptDB = JSON.parse(fs.readFileSync("database/scriptlist.json", "utf-8"));
  } catch (err) {
    return bot.sendMessage(chatId, "🚫 Tidak ada script yang tersedia.");
  }

  if (scriptDB.length === 0) return bot.sendMessage(chatId, "📦 Tidak ada script yang bisa dibeli.");

  let keyboard = {
    reply_markup: {
      inline_keyboard: scriptDB.map(script => [{
        text: `${script.nama} - Rp${script.harga.toLocaleString()} (${script.stok} stok)`,
        callback_data: `beli_${script.id}`
      }])
    }
  };

  bot.sendMessage(chatId, "🛍️ Pilih script yang ingin dibeli:", keyboard);
});

bot.on("callback_query", (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const userId = callbackQuery.from.id;
  const scriptId = callbackQuery.data.split("_")[1];

  let scriptDB;
  try {
    scriptDB = JSON.parse(fs.readFileSync("database/scriptlist.json", "utf-8"));
  } catch (err) {
    return bot.sendMessage(chatId, "🚫 Terjadi kesalahan saat membaca database.");
  }

  let script = scriptDB.find(s => s.id == scriptId);
  if (!script) return bot.sendMessage(chatId, "❌ Script tidak ditemukan.");

  if (script.stok <= 0) {
    return bot.sendMessage(chatId, `⚠️ Stok *${script.nama}* sudah habis.`);
  }

  // Kurangi stok
  script.stok -= 1;
  fs.writeFileSync("database/scriptlist.json", JSON.stringify(scriptDB, null, 2));

  bot.sendMessage(chatId, `✅ Anda telah membeli *${script.nama}*\n💰 Harga: Rp${script.harga.toLocaleString()}\n📦 Sisa Stok: ${script.stok}`, { parse_mode: "Markdown" });

  // Kirim QRIS untuk pembayaran
  bot.sendPhoto(chatId, "qris.jpg", { caption: "🔖 Silakan scan QRIS di atas untuk pembayaran.\nSetelah bayar, kirim bukti pembayaran ke admin." });
});

//~~~~~~~~~< BUYVPS COMMAND >~~~~~~~~//

bot.onText(/^\/belivps$/, (msg) => {
  const chatId = msg.chat.id;

  let vpsDB;
  try {
    vpsDB = JSON.parse(fs.readFileSync("database/vpslist.json", "utf-8"));
  } catch (err) {
    return bot.sendMessage(chatId, "🚫 Database VPS tidak ditemukan.");
  }

  if (vpsDB.length === 0) return bot.sendMessage(chatId, "📦 Tidak ada VPS yang tersedia saat ini.");

  let options = {
    reply_markup: {
      inline_keyboard: vpsDB.map((vps) => [
        { text: `${vps.nama} - Rp${vps.harga.toLocaleString()}`, callback_data: `belivps_${vps.id}` }
      ])
    }
  };

  bot.sendMessage(chatId, "🖥 *Pilih VPS yang ingin dibeli:*\n\n", options);
});

bot.on("callback_query", (query) => {
  const chatId = query.message.chat.id;
  const data = query.data;

  if (data.startsWith("belivps_")) {
    let vpsDB = JSON.parse(fs.readFileSync("database/vpslist.json", "utf-8"));
    let vpsId = data.split("_")[1];
    let selectedVPS = vpsDB.find(v => v.id === vpsId);

    if (!selectedVPS || selectedVPS.stok <= 0) {
      return bot.sendMessage(chatId, "🚫 VPS yang dipilih sudah habis atau tidak tersedia.");
    }

    // Kirim QRIS buat pembayaran
    let qrisMessage = `🛒 *Detail Pembelian VPS*\n\n🖥 Nama: ${selectedVPS.nama}\n💰 Harga: Rp${selectedVPS.harga.toLocaleString()}\n📦 Stok: ${selectedVPS.stok - 1}\n\n🔄 Silakan bayar menggunakan QRIS di bawah ini:`;
    bot.sendPhoto(chatId, "./qris.jpg", { caption: qrisMessage });

    // Kurangi stok
    selectedVPS.stok -= 1;
    fs.writeFileSync("database/vpslist.json", JSON.stringify(vpsDB, null, 2));

    bot.answerCallbackQuery(query.id);
  }
});

//~~~~~~~~~~~~~< STOKVPS COMMAND >~~~~~~~~~~~~//

bot.onText(/^\/stokvps$/, (msg) => {
  const chatId = msg.chat.id;

  let scriptDB;
  try {
    scriptDB = JSON.parse(fs.readFileSync("database/vpslist.json", "utf-8"));
  } catch (err) {
    return bot.sendMessage(chatId, "🚫 Database VPS tidak ditemukan.");
  }

  if (scriptDB.length === 0) return bot.sendMessage(chatId, "📦 Tidak ada VPS yang tersedia saat ini.");

  let response = "📦 *Stok VPS yang Tersedia:*\n\n";
  scriptDB.forEach((vps, index) => {
    response += `🔹 *${vps.nama}*\n💰 Harga: Rp${vps.harga.toLocaleString()}\n📦 Stok: ${vps.stok} pcs\n━━━━━━━━━━━━━━\n`;
  });

  bot.sendMessage(chatId, response, { parse_mode: "Markdown" });
});

//~~~~~~~~~~~~~< STOKDOMAIN COMMAND >~~~~~~~~~~~~//
bot.onText(/\/stokdomain/, (msg) => {
  const chatId = msg.chat.id;
  
  let domainList = [];
  try {
    domainList = JSON.parse(fs.readFileSync("database/domainlist.json", "utf-8"));
  } catch (err) {
    return bot.sendMessage(chatId, "⚠️ Data domain tidak ditemukan.");
  }

  if (domainList.length === 0) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada domain yang tersedia.");
  }

  let stokText = "📌 **Stok Domain Tersedia:**\n\n";
  domainList.forEach((domain, index) => {
    stokText += `${index + 1}. ${domain.name} - Sisa: ${domain.stock}\n`;
  });

  bot.sendMessage(chatId, stokText, { parse_mode: "Markdown" });
});

//~~~~~~~~~~~~< STOKSC COMMAND >~~~~~~~~~//

bot.onText(/^\/stoksc$/, (msg) => {
  const chatId = msg.chat.id;

  let scriptDB;
  try {
    scriptDB = JSON.parse(fs.readFileSync("database/scriptlist.json", "utf-8"));
  } catch (err) {
    return bot.sendMessage(chatId, "🚫 Database script tidak ditemukan.");
  }

  if (scriptDB.length === 0) return bot.sendMessage(chatId, "📦 Tidak ada script yang tersedia saat ini.");

  let response = "📦 *Stok Script yang Tersedia:*\n\n";
  scriptDB.forEach((script, index) => {
    response += `🔹 *${script.nama}*\n💰 Harga: Rp${script.harga.toLocaleString()}\n📦 Stok: ${script.stok} pcs\n━━━━━━━━━━━━━━\n`;
  });

  bot.sendMessage(chatId, response, { parse_mode: "Markdown" });
});

//~~~~~~~~~~~< REKAP TRX COMMAND >~~~~~~~~~~//
const moment = require("moment");

bot.onText(/^\/rekaptransaksi$/, (msg) => {
  const chatId = msg.chat.id;
  const transaksiPath = "./database/transaksi.json";

  if (!fs.existsSync(transaksiPath)) {
    return bot.sendMessage(chatId, "❌ Belum ada transaksi yang tercatat.");
  }

  const transaksi = JSON.parse(fs.readFileSync(transaksiPath, "utf8"));
  const today = moment().format("YYYY-MM-DD");

  let totalProduk = {};
  let transaksiHariIni = 0;
  let saldoHariIni = 0;
  let totalKeuntungan = 0;
  let totalTransaksi = transaksi.length;

  transaksi.forEach((trx) => {
    if (!totalProduk[trx.produk]) {
      totalProduk[trx.produk] = 0;
    }
    totalProduk[trx.produk]++;

    if (trx.tanggal === today) {
      transaksiHariIni++;
      saldoHariIni += trx.harga;
    }
    
    totalKeuntungan += trx.harga;
  });

  let produkTerbanyak = Object.keys(totalProduk).reduce((a, b) => (totalProduk[a] > totalProduk[b] ? a : b), "");

  let rekapPesan = `
📊 *REKAP TRANSAKSI* 📊

🔝 Produk Paling Banyak Dibeli: ${produkTerbanyak || "Belum ada"}
📅 Transaksi Hari Ini: ${transaksiHariIni}
💰 Saldo Hari Ini: Rp${saldoHariIni.toLocaleString()}
📈 Total Keuntungan: Rp${totalKeuntungan.toLocaleString()}
📦 Total Semua Transaksi: ${totalTransaksi}
  `;

  bot.sendMessage(chatId, rekapPesan);
});

//~~~~~~~~~~< ADD PANEL COMMAND >~~~~~~~~~~//
bot.onText(/^\/addpanel$/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  bot.sendMessage(chatId, "📝 Masukkan nama panel:")
    .then(() => {
      bot.once("message", (namaPanelMsg) => {
        const namaPanel = namaPanelMsg.text;
        bot.sendMessage(chatId, "💰 Masukkan harga panel:");

        bot.once("message", (hargaMsg) => {
          const harga = parseInt(hargaMsg.text);
          if (isNaN(harga)) return bot.sendMessage(chatId, "❌ Harga harus angka!");

          bot.sendMessage(chatId, "📜 Masukkan deskripsi panel:");

          bot.once("message", (deskripsiMsg) => {
            const deskripsi = deskripsiMsg.text;
            const panelPath = "./database/panel.json";

            let panelData = [];
            if (fs.existsSync(panelPath)) {
              panelData = JSON.parse(fs.readFileSync(panelPath, "utf8"));
            }

            panelData.push({ namaPanel, harga, deskripsi });
            fs.writeFileSync(panelPath, JSON.stringify(panelData, null, 2));

            bot.sendMessage(chatId, `✅ Panel *${namaPanel}* berhasil ditambahkan!`);
          });
        });
      });
    });
});

//~~~~~~~~~~~< BELI PANEL COMMAND >~~~~~~~~~~//
bot.onText(/^\/belipanel$/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const panelPath = "./database/panel.json";
  const transaksiPath = "./database/transaksi.json";

  if (!fs.existsSync(panelPath)) return bot.sendMessage(chatId, "❌ Tidak ada panel yang tersedia.");
  const panelData = JSON.parse(fs.readFileSync(panelPath, "utf8"));

  let panelButtons = panelData.map((panel, index) => [{
    text: `${panel.namaPanel} - Rp${panel.harga.toLocaleString()}`,
    callback_data: `belipanel_${index}`
  }]);

  bot.sendMessage(chatId, "💻 Pilih panel yang ingin dibeli:", {
    reply_markup: { inline_keyboard: panelButtons }
  });
});

bot.on("callback_query", (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const userId = callbackQuery.from.id;
  const data = callbackQuery.data;

  if (!data.startsWith("belipanel_")) return;
  const panelIndex = parseInt(data.split("_")[1]);
  const panelPath = "./database/panel.json";
  const transaksiPath = "./database/transaksi.json";

  if (!fs.existsSync(panelPath)) return bot.sendMessage(chatId, "❌ Tidak ada panel yang tersedia.");
  const panelData = JSON.parse(fs.readFileSync(panelPath, "utf8"));

  if (panelIndex >= panelData.length) return bot.sendMessage(chatId, "❌ Panel tidak ditemukan!");

  const panel = panelData[panelIndex];

  bot.sendMessage(chatId, "📌 Silakan lakukan pembayaran melalui QRIS ini:");
  bot.sendPhoto(chatId, "qris.jpg", {
    caption: `🔹 *Panel:* ${panel.namaPanel}\n💰 *Harga:* Rp${panel.harga.toLocaleString()}\n\n✅ Kirim bukti pembayaran ke admin setelah transfer!`
  });

  let transaksiData = [];
  if (fs.existsSync(transaksiPath)) {
    transaksiData = JSON.parse(fs.readFileSync(transaksiPath, "utf8"));
  }

  transaksiData.push({
    userId,
    produk: panel.namaPanel,
    harga: panel.harga,
    tanggal: new Date().toISOString().split("T")[0]
  });

  fs.writeFileSync(transaksiPath, JSON.stringify(transaksiData, null, 2));
});

//~~~~~~~~< TEBAK KATA COMMAND >~~~~~~~~//
const tebakKataList = [
  { soal: "Bahasa pemrograman yang dibuat oleh Guido van Rossum?", jawaban: "python" },
  { soal: "Bahasa yang sering dipakai untuk buat web interaktif?", jawaban: "javascript" },
  { soal: "SQL dipakai buat mengelola apa?", jawaban: "database" },
  { soal: "Metode untuk mencari bug di kode?", jawaban: "debugging" },
  { soal: "Tempat menyimpan kode secara online?", jawaban: "github" }
];

const tebakKataSessions = {}; // Simpan sesi tebak kata user

bot.onText(/\/tebakkata/, (msg) => {
  const chatId = msg.chat.id;
  const randomIndex = Math.floor(Math.random() * tebakKataList.length);
  const { soal, jawaban } = tebakKataList[randomIndex];

  tebakKataSessions[chatId] = jawaban.toLowerCase(); // Simpan jawaban di sesi user

  bot.sendMessage(chatId, `🧩 Tebak Kata:\n\n❓ *${soal}*`, { parse_mode: "Markdown" });
});

// Tangkap jawaban user
bot.on("message", (msg) => {
  const chatId = msg.chat.id;
  const userAnswer = msg.text.toLowerCase();

  if (tebakKataSessions[chatId]) {
    if (userAnswer === tebakKataSessions[chatId]) {
      updateExp(msg.from.id, msg.from.username, 10); // Tambah EXP
      bot.sendMessage(chatId, "✅ Jawaban benar! Kamu dapat 10 EXP!");
      delete tebakKataSessions[chatId]; // Hapus sesi
    } else {
      const hint = tebakKataSessions[chatId][0]; // Ambil huruf pertama sebagai hint
      bot.sendMessage(chatId, `❌ Jawaban salah! Hint: "${hint}..."`);
    }
  }
});

// Fungsi update EXP
const updateExp = (userId, username, expTambah) => {
  let database;
  try {
    database = JSON.parse(fs.readFileSync("database/database.json", "utf-8"));
  } catch (err) {
    database = [];
  }

  let user = database.find(u => u.id === userId);

  if (!user) {
    user = { id: userId, username: username, saldo: 0, dana: 0, exp: 0, level: 1 };
    database.push(user);
  }

  user.exp += expTambah;
  if (user.exp >= 100) {
    user.level += 1;
    user.exp = 0;
  }

  fs.writeFileSync("database/database.json", JSON.stringify(database, null, 2));
};

//~~~~~~~~~< SHORTURL COMMAND >~~~~~~~~~//
bot.onText(/\/shorturl (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const url = match[1];

  if (!url.startsWith("http")) {
    return bot.sendMessage(chatId, "❌ Masukkan URL yang valid! Contoh: /shorturl https://example.com");
  }

  try {
    const response = await axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(url)}`);
    const shortUrl = response.data;

    bot.sendMessage(chatId, `\`\`\`BERIKUT SHORTURL ANDA :\n${shortUrl}\`\`\``, { parse_mode: "MarkdownV2" });
  } catch (error) {
    bot.sendMessage(chatId, "⚠️ Gagal memperpendek URL, coba lagi nanti.");
  }
});

//~~~~~~~~< DOMAIN COMMAND >~~~~~~~~~//
bot.onText(/\/adddomain/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  bot.sendMessage(chatId, "📌 Masukkan nama domain:").then(() => {
    bot.once("message", (msg) => {
      const domainName = msg.text;

      bot.sendMessage(chatId, "💰 Masukkan harga domain:").then(() => {
        bot.once("message", (msg) => {
          const price = parseInt(msg.text);
          if (isNaN(price)) return bot.sendMessage(chatId, "⚠️ Harga harus angka!");

          bot.sendMessage(chatId, "📜 Masukkan deskripsi domain:").then(() => {
            bot.once("message", (msg) => {
              const description = msg.text;

              bot.sendMessage(chatId, "📦 Masukkan stok domain:").then(() => {
                bot.once("message", (msg) => {
                  const stock = parseInt(msg.text);
                  if (isNaN(stock)) return bot.sendMessage(chatId, "⚠️ Stok harus angka!");

                  let domainList = [];
                  try {
                    domainList = JSON.parse(fs.readFileSync("database/domainlist.json", "utf-8"));
                  } catch (err) {}

                  domainList.push({
                    name: domainName,
                    price: price,
                    description: description,
                    stock: stock
                  });

                  fs.writeFileSync("database/domainlist.json", JSON.stringify(domainList, null, 2));
                  bot.sendMessage(chatId, `✅ Domain *${domainName}* berhasil ditambahkan!`, { parse_mode: "Markdown" });
                });
              });
            });
          });
        });
      });
    });
  });
});

//~~~~~~~< BELI DOMAIN COMMAND >~~~~~~//
bot.onText(/\/belidomain/, (msg) => {
  const chatId = msg.chat.id;
  let domainList = [];

  try {
    domainList = JSON.parse(fs.readFileSync("database/domainlist.json", "utf-8"));
  } catch (err) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada domain yang tersedia.");
  }

  if (domainList.length === 0) return bot.sendMessage(chatId, "⚠️ Tidak ada domain yang tersedia.");

  let domainText = "📌 List Domain yang Tersedia:\n\n";
  domainList.forEach((domain, index) => {
    domainText += `${index + 1}. ${domain.name} - Rp${domain.price} (${domain.stock} stok)\n`, { parse_mode: "Markdown" };
  });

  domainText += "\nKetik: \`/pilihdomain [nomor]\` untuk beli\nContoh: \`/pilihdomain 1\`";

  bot.sendMessage(chatId, domainText, { parse_mode: "Markdown" });
});

bot.onText(/\/pilihdomain (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const nomor = parseInt(match[1]) - 1;

  let domainList = JSON.parse(fs.readFileSync("database/domainlist.json", "utf-8"));

  if (!domainList[nomor]) {
    return bot.sendMessage(chatId, "❌ Domain tidak ditemukan.");
  }

  let selectedDomain = domainList[nomor];

  if (selectedDomain.stock <= 0) {
    return bot.sendMessage(chatId, "❌ Stok domain ini sudah habis.");
  }

  bot.sendMessage(chatId, `💰 Harga Domain *${selectedDomain.name}* : Rp${selectedDomain.price}\n\n📌 Kirim pembayaran ke QRIS di bawah ini:`, { parse_mode: "Markdown" });

  bot.sendPhoto(chatId, "qris.jpg", {
    caption: `🔗 Setelah melakukan pembayaran, kirim bukti transaksi ke admin.\n\n📞 Kontak Admin : t.me/KenzDeveloper`
  });

  // Simpan transaksi
  let transaksiList = [];
  try {
    transaksiList = JSON.parse(fs.readFileSync("database/transaksi.json", "utf-8"));
  } catch (err) {}

  transaksiList.push({
    userId: userId,
    domain: selectedDomain.name,
    price: selectedDomain.price,
    status: "pending"
  });

  fs.writeFileSync("database/transaksi.json", JSON.stringify(transaksiList, null, 2));

  // Kurangi stok
  domainList[nomor].stock -= 1;
  fs.writeFileSync("database/domainlist.json", JSON.stringify(domainList, null, 2));
});

//~~~~~~~~< RECEIPT COMMAND >~~~~~~~~//
bot.onText(/\/receipt (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1].split('|');

  if (input.length < 3) {
    return bot.sendMessage(chatId, '⚠️ Format salah! Gunakan: `/receipt NamaBarang|JumlahBarang|NomorPelanggan`');
  }

  const namaBarang = input[0].trim();
  const jumlahBarang = input[1].trim();
  const nomorPelanggan = input[2].trim();
  const idTrx = Math.floor(1000000000 + Math.random() * 9000000000);
  const tanggal = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

  // Format struk pembayaran
  const strukText = `
🧾 *STRUK PEMBAYARAN*
📌 Nama Barang: *${namaBarang}*
📌 ID TRX: *${idTrx}*
📌 Jumlah Barang: *${jumlahBarang}*
📌 Trx Ke:- *${nomorPelanggan}*
📌 Nomor Pelanggan: *SNID-${idTrx}*
📌 Tanggal: *${tanggal}*
  `;

  const filePath = `./donetrx_${idTrx}.txt`;
  const fileContent = `
============================
        STRUK PEMBAYARAN
============================
Nama Barang   : ${namaBarang}
ID TRX        : ${idTrx}
Jumlah Barang : ${jumlahBarang}
Trx Ke :- ${nomorPelanggan}
Nomor Pelanggan : ${idTrx}
Tanggal       : ${tanggal}
============================
Terima kasih telah bertransaksi!
`;

  fs.writeFileSync(filePath, fileContent, 'utf8');

  // Kirim struk dalam bentuk teks dulu
  await bot.sendMessage(chatId, strukText, { parse_mode: 'Markdown' });

  // Pastikan file tersedia sebelum dikirim
  setTimeout(() => {
    bot.sendDocument(chatId, filePath, {
      caption: '✅ Struk pembayaran berhasil dibuat!'
    }).catch(err => bot.sendMessage(chatId, '❌ Gagal mengirim file!'));
  }, 1000); // Delay sedikit agar file tersimpan dengan sempurna
});

//~~~~~~~< batas akhir >~~~~~~~~~//
};